from django.apps import AppConfig


class PopulateConfig(AppConfig):
    name = 'populate'
