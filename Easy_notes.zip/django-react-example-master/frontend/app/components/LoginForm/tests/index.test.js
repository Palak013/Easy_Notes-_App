// import React from 'react';
// import { shallow } from 'enzyme';

// import LoginForm from '../index';

describe('<LoginForm />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
