// import React from 'react';
// import { shallow } from 'enzyme';

// import TagsWidget from '../index';

describe('<TagsWidget />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
