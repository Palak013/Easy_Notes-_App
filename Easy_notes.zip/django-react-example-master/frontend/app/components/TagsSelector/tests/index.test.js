// import React from 'react';
// import { shallow } from 'enzyme';

// import TagsSelector from '../index';

describe('<TagsSelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
