// import { fromJS } from 'immutable';
// import { selectNotesPageDomain } from '../selectors';

describe('selectNotesPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
