// import { fromJS } from 'immutable';
// import { selectPopularTagsDomain } from '../selectors';

describe('selectPopularTagsDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
