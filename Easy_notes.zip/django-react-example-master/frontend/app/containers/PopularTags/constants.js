/*
 *
 * PopularTags constants
 *
 */

export const DEFAULT_ACTION = 'app/PopularTags/DEFAULT_ACTION';

export const FETCH_TAGS_PROCESS = 'app/PopularTags/FETCH_TAGS_PROCESS';
export const FETCH_TAGS_SUCCESS = 'app/PopularTags/FETCH_TAGS_SUCCESS';
