/*
 *
 * NoteVoteWidget constants
 *
 */

export const DEFAULT_ACTION = 'app/NoteVoteWidget/DEFAULT_ACTION';
export const UPVOTE_PROCESS = 'app/NotesPage/UPVOTE_PROCESS';
export const DOWNVOTE_PROCESS = 'app/NotesPage/DOWNVOTE_PROCESS';
export const UPVOTE_SUCCESS = 'app/NotesPage/UPVOTE_SUCCESS';
export const DOWNVOTE_SUCCESS = 'app/NotesPage/DOWNVOTE_SUCCESS';
