// import { fromJS } from 'immutable';
// import { selectNoteVoteWidgetDomain } from '../selectors';

describe('selectNoteVoteWidgetDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
