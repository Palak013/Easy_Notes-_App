/*
 *
 * LoginPage constants
 *
 */

export const DEFAULT_ACTION = 'app/LoginPage/DEFAULT_ACTION';
export const REGISTER_PROCESS = 'app/LoginPage/REGISTER_PROCESS';
export const REGISTER_SUCCESS = 'app/LoginPage/REGISTER_SUCCESS';
export const REGISTER_FAIL = 'app/LoginPage/REGISTER_FAIL';
